﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppDev3AViewModel
{
    public class BlobViewModel
    {
        public string Name { get; set; }
        public string URI { get; set; }
        public string StudentNumber { get; set; }
    }
}
